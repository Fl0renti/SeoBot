let platform="";
window.onload=function(){
  

// Opera 8.0+
var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

// Firefox 1.0+
var isFirefox = typeof InstallTrigger !== 'undefined';

// Safari 3.0+ "[object HTMLElementConstructor]" 
var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

// Edge 20+
var isEdge = window.navigator.userAgent.indexOf("Edg/") > -1 ? true : false;

// Chrome 1 - 71
var isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);



if(isChrome){
    //reviewLink.setAttribute("href","https://addons.mozilla.org/en-US/firefox/addon/testcase-studio/");
    platform = "chrome";
}

if(isFirefox){
    platform = "firefox";
}

if(isOpera){
    platform = "opera";
}

if(isEdge){
    platform = "Edge";
    
}
 trackEvent("Click on Logo at toolbar");
 //console.log("onload");
};

function trackEvent(event){

    var settings = {
      "url": "http://ip-api.com/json/",
      "method": "GET",
      "timeout": 0,
    };

    // $.ajax(settings).done(function (response) {
    //     const country=response.country;

    //     var settings = {
    //         "url": "https://api2.amplitude.com/2/httpapi",
    //         "method": "POST",
    //         "timeout": 0,
    //         "headers": {
    //             "Content-Type": "application/json"
    //         },
    //         "data": JSON.stringify({
    //             "api_key": "9e44349fd8ccbd144f9eebe40c5472a1",
    //             "events": [{
    //                 "user_id": response.query,
    //                 "event_type": event,
    //                 "user_properties": {"Cohort": "Test A"},
    //                 "country": country,
    //                 "city": response.city,
    //                 "timezone":response.timezone,
    //                 "region":response.regionName,
    //                 "carrier": response.isp,
    //                 "platform": platform
    //             }]
    //         }),
    //     };

    //     $.ajax(settings).done(function (response) {});

    // }); 
}

