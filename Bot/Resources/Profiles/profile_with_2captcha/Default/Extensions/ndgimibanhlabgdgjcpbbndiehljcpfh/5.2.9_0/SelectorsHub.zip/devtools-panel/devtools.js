/**
 * Created by sanjay kumar on 25/06/2020.
 */
var isFirefox = typeof InstallTrigger !== 'undefined';

var browserType = chrome;
if(isFirefox){
    browserType = browser;
}

var connectBackgroundPage = browserType.runtime.connect({
	name: "devtools-page"
});

browserType.devtools.panels.elements.createSidebarPane("SelectorsHub",
          function(sidebar) {
            sidebar.setPage("../devtools-panel/shub-panel.html");
            sidebar.onShown.addListener(openedTab);
            sidebar.onHidden.addListener(closedTab);
          }
);

function openedTab() {
  browserType.runtime.sendMessage({
  	message: "generate-selector"
  });
}

function closedTab() {
  var xpathOrCss = 'xpath';
  var onChange = false;
  var xpath = [xpathOrCss, '//sanjay', onChange];
  connectBackgroundPage.postMessage({
      name: "highlight-element",
      tabId: browserType.devtools.inspectedWindow.tabId,
      xpath: xpath
  });   
}

